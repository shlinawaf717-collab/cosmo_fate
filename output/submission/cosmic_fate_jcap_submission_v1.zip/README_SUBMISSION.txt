JCAP/arXiv portable source package
=================================

Root file: main.tex
Target: JCAP (official jcappub.sty, downloaded 2026-08-25)

The archive is self-contained: it includes the bibliography source and BBL,
generated numerical macros, the official JCAP style/BibTeX files, and every
figure used by main.tex. It intentionally excludes the compiled PDF and all
unused repository files.

Reference build used for release QA:

    tectonic --keep-logs --keep-intermediates main.tex

For JCAP submission, upload the source archive and ensure that main.tex is
selected as the root file. For arXiv, upload the same archive so that the
public preprint and journal submission are built from identical sources.
